import requests,bs4,json,pathlib,concurrent.futures,time
root=pathlib.Path('work/raw');root.mkdir(exist_ok=True)
url='https://my.sa.ucsb.edu/public/curriculum/coursesearch.aspx'
html=pathlib.Path('work/search.html').read_text(); soup=bs4.BeautifulSoup(html,'html.parser')
base={e['name']:e.get('value','') for e in soup.select('input[type=hidden]')}
subjects=[(e['value'],e.get_text(' ',strip=True)) for e in soup.select('#ctl00_pageContent1_courseList option')]
pathlib.Path('work/subjects.json').write_text(json.dumps(subjects,indent=2))
def run(task):
 year,idx,sub=task;fn=root/f'{year}_{idx:03}.html'
 if fn.exists():return
 data=base|{'ctl00$pageContent1$courseList':sub,'ctl00$pageContent1$quarterList':f'{year}3','ctl00$pageContent1$dropDownCourseLevels':'All','ctl00$pageContent1$searchButton.x':'10','ctl00$pageContent1$searchButton.y':'10'}
 for retry in range(4):
  try:
   r=requests.post(url,data=data,timeout=60);r.raise_for_status();s=bs4.BeautifulSoup(r.text,'html.parser')
   assert s.select_one('#ctl00_pageContent1_quarterList option[selected]')['value']==f'{year}3'
   assert s.select_one('#ctl00_pageContent1_courseList option[selected]')['value']==sub
   fn.write_text(r.text);return
  except Exception:
   if retry==3:raise
   time.sleep(2)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for i,_ in enumerate(pool.map(run,[(y,i,s[0]) for y in [2025,2026] for i,s in enumerate(subjects)])):
  if i%20==0:print(i,flush=True)
print('complete',len(subjects)*2)
