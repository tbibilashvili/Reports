import json,collections,re,pathlib,csv,hashlib,zipfile,datetime
rs=json.load(open('work/classified.json')); groups=collections.defaultdict(list)
for r in rs:groups[r['group']].append(r)
primary=[r for r in rs if r['primary']]; byid={r['id']:r for r in primary}
merges=[['2025-018-018','2025-041-005'],['2025-018-019','2025-041-004'],['2026-018-006','2026-041-003'],['2026-018-018','2026-045-004','2026-087-000']]
for r in primary:
 locs=[x['location'] for x in groups[r['id']] if (x['primary'] or (x['enrolled'] or 0)>0) and 'cancel' not in x['status'].lower()]
 online=any('ON LINE' in x or 'ON ASYNC' in x for x in locs)
 physical=any(x not in ['','T B A','NO ROOM'] and not x.startswith('ON ') for x in locs)
 r['modality']='Hybrid' if online and physical else 'Online' if online else 'In person' if physical else 'Unknown / arranged'
 r['component_locations']='; '.join(sorted(set(locs)))
 sessions={x['code_session'].split('/')[1] for x in groups[r['id']] if '/' in x['code_session']}
 r['session']='; '.join(sorted(sessions));r['class_id']=r['id'];r['class_count']=0;r['enrollment_count']=0;r['note']=''
 if r['enrolled']==0 and not r['reason']:
  if r['location'] in ['','T B A','NO ROOM'] and not r['days'] and not r['time']:
   r['reason']='Arranged zero-enrollment placeholder'
  else:r['reason']='Zero-enrollment scheduled listing (retained in sensitivity)'
 if not r['reason']:
  r['include']=1;r['class_count']=1;r['enrollment_count']=r['enrolled'];r['reason']='Include regular instructional offering'
 else:r['include']=0
 if r['modality']=='Unknown / arranged' and r['include']:r['note']='Retained instruction; delivery location cannot be established from schedule.'
for ids in merges:
 for id in ids[1:]:
  r=byid[id];assert r['include'];r['class_count']=0;r['class_id']=ids[0];r['note']='Cross-listed with '+', '.join(byid[i]['course'] for i in ids if i!=id)+'; enrollment retained, shared class counted once.'
 byid[ids[0]]['note']='Shared class with '+', '.join(byid[i]['course'] for i in ids[1:])+'. Enrollment summed across listings.'
# Deduplicate repeated search result record; this one is excluded independent study.
seen={}
for r in primary:
 k=(r['year'],r['code_session'])
 if r['code_session'] and k in seen:
  r['note']='Duplicate of '+seen[k]+'. '+r['note'];assert not r['include']
 else:seen[k]=r['id']
for r in rs:
 if not r['primary']:
  r.update(include=0,class_count=0,enrollment_count=0,class_id=r['group'],session=r['code_session'].split('/')[1] if '/' in r['code_session'] else '',note='Associated with primary '+str(r['group']))
for r in primary:
 if 0<(r['enrolled'] or 0)<=3:
  if r['include']:
   r['tiny_review']='Retain: '+r['full_title']+'. '+r['description']+' '+r['note']
  else:r['tiny_review']='Exclude: '+r['reason']+'. '+r['description']
 else:r['tiny_review']=''
mods=['Online','In person','Hybrid','Unknown / arranged'];divs=sorted(set(r['division'] for r in primary));summary=[]
for y in [2025,2026]:
 for d in ['All divisions']+divs:
  pop=[r for r in primary if r['year']==y and r['include'] and (d=='All divisions' or r['division']==d)]
  n=sum(r['class_count'] for r in pop);e=sum(r['enrollment_count'] for r in pop)
  for m in mods:
   p=[r for r in pop if r['modality']==m];nc=sum(r['class_count'] for r in p);ec=sum(r['enrollment_count'] for r in p)
   summary.append(dict(year=y,division=d,modality=m,classes=nc,enrollments=ec,class_share=nc/n if n else None,enrollment_share=ec/e if e else None,average=ec/nc if nc else None))
pathlib.Path('work/final.json').write_text(json.dumps(dict(rows=rs,primary=primary,summary=summary,merges=merges,divisions=divs),indent=2))
for y in [2025,2026]:
 print(y,'ALL',[(r['modality'],r['classes'],r['enrollments'],round(r['class_share']*100,2),round(r['enrollment_share']*100,2),round(r['average'],2) if r['average'] else None) for r in summary if r['year']==y and r['division']=='All divisions'])
 print('zero scheduled',[(r['course'],r['code_session'],r['status']) for r in primary if r['year']==y and r['reason'].startswith('Zero-enrollment')])
 print('reasons',collections.Counter(r['reason'] for r in primary if r['year']==y))
 print('division',[ (d,sum(r['class_count'] for r in primary if r['year']==y and r['division']==d),sum(r['enrollment_count'] for r in primary if r['year']==y and r['division']==d)) for d in divs])
