import bs4,pathlib,json,re,collections
subs=json.loads(pathlib.Path('work/subjects.json').read_text()); rows=[]
def clean(x):return ' '.join(x.split())
for fn in sorted(pathlib.Path('work/raw').glob('*.html')):
 year,idx=map(int,fn.stem.split('_'));s=bs4.BeautifulSoup(fn.read_text(),'html.parser'); group=None
 for n,tr in enumerate(s.select('table.gridview > tr')):
  td=tr.find_all('td',recursive=False)
  if len(td)!=11:continue
  course=clean(' '.join(td[1].find_all(string=True,recursive=False)))
  def label(end):
   e=td[1].select_one('[id$="'+end+'"]');return clean(e.get_text()) if e else ''
  title=clean(td[2].get_text()); primary=bool(title); code=td[4].select_one('a');code=clean(code.get_text()) if code else ''
  if primary:group=f'{year}-{idx:03}-{n:03}'
  enr=clean(td[9].get_text());m=re.fullmatch(r'(\d+)\s*/\s*(\d+)',enr)
  rows.append(dict(year=year,subject=subs[idx][0].strip(),id=f'{year}-{idx:03}-{n:03}',group=group,primary=primary,course=course,title=title,full_title=label('labelTitle'),description=label('labelDescription'),college=label('labelCollege'),code_session=code,status=clean(td[3].get_text()),instructor=clean(td[5].get_text()),days=clean(td[6].get_text()),time=clean(td[7].get_text()),location=clean(td[8].get_text()),enrolled=int(m[1]) if m else None,capacity=int(m[2]) if m else None,source_file=str(fn),source_row=n))
pathlib.Path('work/rows.json').write_text(json.dumps(rows,indent=2))
print('files',len(list(pathlib.Path('work/raw').glob('*.html'))),'rows',len(rows),'primary',sum(r['primary'] for r in rows))
print('statuses',collections.Counter(r['status'] for r in rows))
print('locations',collections.Counter(r['location'] for r in rows))
