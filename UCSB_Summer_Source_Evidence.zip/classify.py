import json,re,collections,pathlib
rs=json.load(open('work/rows.json')); groups=collections.defaultdict(list)
for r in rs:groups[r['group']].append(r)
ss=set('ANTH|AS AM|BL ST|CH ST|COMM|ECON|ESS|ES|FEMST|GPS|GLOBL|MS|POL S|SOC'.split('|'))
sc=set('ASTRO|BIOL|CHEM|DYNS|EARTH|EEMB|ENV S|GEOG|IQB|MARSC|MATH|MCDB|PHYS|PSY|PSTAT'.split('|'))
eng=set('BIOE|CH E|CMPSC|ECE|ENGR|MATRL|ME|TMP'.split('|'))
ccs=set(s[0].strip() for s in json.load(open('work/subjects.json')) if 'Creative Studies' in s[1])
def division(s):
 if s in ccs:return 'Creative Studies'
 if s in ss:return 'Social Sciences'
 if s in sc:return 'Mathematical, Life & Physical Sciences'
 if s in eng:return 'Engineering'
 if s in ['ED','CNCSP']:return 'Education'
 if s in ['EDS','ESM']:return 'Bren School'
 if s in ['INT','GRAD']:return 'Interdisciplinary / Other'
 return 'Humanities & Fine Arts'
def reason(r):
 num=re.search(r'\d+',r['course']);num=int(num[0]) if num else -1
 title=r['title']; desc=r['description']
 if re.search('cancel',r['status'],re.I):return 'Canceled'
 if num in [98,99,198,199,596,597,598,599]:return 'Independent study / directed reading / research / thesis'
 if re.search(r'INDEP|INDEPEND|DIR.*(READ|RES|STUD)|DISS|THESIS|IND.*ST(U|D)|RESEARCH (TRAIN|ASST)|RES PRACT|RESEARCH PRACT',title,re.I):return 'Independent study / directed reading / research / thesis'
 if re.search(r'INTERN|STUDENT TCH|STU TCH|FIELDWORK',title,re.I):return 'Individual internship / student teaching / fieldwork'
 return ''
for r in rs:
 r['division']=division(r['subject']);r['reason']=reason(r) if r['primary'] else 'Secondary section (not separately counted)'
 if r['primary']:
  locs=[x['location'] for x in groups[r['group']] if x['enrolled'] is not None and x['enrolled']>0 and 'cancel' not in x['status'].lower()]
  online=any('ON LINE' in x or 'ON ASYNC' in x for x in locs)
  physical=any(x not in ['','T B A','NO ROOM'] and not x.startswith('ON ') for x in locs)
  r['modality']='Hybrid' if online and physical else 'Online' if online else 'In person' if physical else 'Unknown / arranged'
  r['component_locations']='; '.join(sorted(set(locs)))
  r['include']=int(not r['reason'])
pathlib.Path('work/classified.json').write_text(json.dumps(rs,indent=2))
print('nonexcluded zero primary')
for r in rs:
 if r['primary'] and r['include'] and r['enrolled']==0:print(r['id'],r['course'],r['title'],r['status'],r['instructor'],r['days'],r['time'],r['location'],r['capacity'])
print('nonexcluded unknown primary')
for r in rs:
 if r['primary'] and r['include'] and r['enrolled']>0 and r['modality']=='Unknown / arranged':print(r['id'],r['course'],r['title'],r['enrolled'],r['description'])
