UCSB public course-search evidence collected October 18, 2026.
Query coverage: 98 subjects x 2 summer quarters, level All.
Scripts require Python 3, requests and beautifulsoup4. Run from a directory containing work/ and outputs/.
main dataset: final.json. Raw HTML plus checksums support independent verification.
Source row = zero-based direct tr of table.gridview. The course metadata popups are preserved in HTML.
Enrollment freeze date is not certified by the public source.
